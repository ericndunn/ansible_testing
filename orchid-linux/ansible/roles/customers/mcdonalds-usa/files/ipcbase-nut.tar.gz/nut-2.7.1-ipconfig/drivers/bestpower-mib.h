#ifndef BESTPOWER_MIB_H
#define BESTPOWER_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	bestpower;

#endif /* BESTPOWER_MIB_H */
