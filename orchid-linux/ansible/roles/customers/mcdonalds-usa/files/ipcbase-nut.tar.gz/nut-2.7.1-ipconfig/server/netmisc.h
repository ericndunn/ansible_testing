#ifdef __cplusplus
/* *INDENT-OFF* */
extern "C" {
/* *INDENT-ON* */
#endif

void net_ver(nut_ctype_t *client, int numarg, const char **arg);
void net_netver(nut_ctype_t *client, int numarg, const char **arg);
void net_help(nut_ctype_t *client, int numarg, const char **arg);
void net_fsd(nut_ctype_t *client, int numarg, const char **arg);

#ifdef __cplusplus
/* *INDENT-OFF* */
}
/* *INDENT-ON* */
#endif

