#ifndef CYBERPOWER_MIB_H
#define CYBERPOWER_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	cyberpower;

#endif /* CYBERPOWER_MIB_H */
