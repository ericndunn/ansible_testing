#ifndef BAYTECH_MIB_H
#define BAYTECH_MIB_H

#include "main.h"
#include "snmp-ups.h"

extern mib2nut_info_t	baytech;

#endif /* BAYTECH_MIB_H */
